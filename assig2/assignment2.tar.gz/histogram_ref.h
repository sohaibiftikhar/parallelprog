#ifndef HISTOGRAM_REF_H_
#define HISTOGRAM_REF_H_

void get_histogram_ref(char* buffer, int *histogram);

#endif /* HISTOGRAM_REF_H_ */

#include "histogram.h"

#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

#include "names.h"

void get_histogram(char *buffer, int* histogram, int num_threads)
{
	// write your parallel solution here
}

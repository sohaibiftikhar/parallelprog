#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

#include "histogram.h"

void get_histogram(int nBlocks, block_t *blocks, histogram_t histogram, int num_threads)
{
	// write your parallel solution here
}

#ifndef HISTOGRAM_REF_H_
#define HISTOGRAM_REF_H_

void get_histogram_ref(int nBlocks, block_t *blocks, histogram_t histogram);

#endif /* HISTOGRAM_REF_H_ */
